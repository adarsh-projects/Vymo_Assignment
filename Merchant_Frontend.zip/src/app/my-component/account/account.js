function displayInput(id) {
    document.getElementById(''+id+'').disabled = false;
}