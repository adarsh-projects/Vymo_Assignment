import { Component, OnInit } from '@angular/core';
import { ApicallService } from 'src/app/apicall.service';
declare const displayInput:any
declare const enrollno:any
@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css']
})
export class AccountComponent implements OnInit {
  mer_name:String = "";
  contact_num:Number = 0  ;
  pincode:Number = 0;
  location:String = "";
  mer_id:Number = 0;
  website:String = "";
  phone_num:Number = 0;
  avg_daily_transaction:Number = 0;
  constructor(private apicall: ApicallService) {
    this.apicall.getByMerchantId(enrollno).subscribe(data=>{
      let obj = JSON.parse(JSON.stringify(data))[0];
      
      this.mer_id = obj.mer_id
      this.mer_name = obj.mer_name;
      this.phone_num = obj.phone_num;
      this.contact_num = obj.contact_num;
      this.pincode = obj.pincode;
      this.website = obj.website;
      this.location = obj.location;
      this.avg_daily_transaction = obj.avg_daily_transaction;
    })
   }
  callFun(id:String){
    displayInput(id);
  }
  saveData(){
    if (this.mer_id > 0 && this.mer_name != "" && this.phone_num > 0 && this.contact_num > 0 
          && this.pincode > 0 && this.website != "" &&  this.location != "" && this.avg_daily_transaction > 0) {
            const userData = {
              mer_id: this.mer_id,
              mer_name: this.mer_name,
              phone_num: this.phone_num,
              contact_num: this.contact_num,
              pincode: this.pincode,
              website: this.website,
              location: this.location,
              avg_daily_transaction: this.avg_daily_transaction
            }
      
            this.apicall.updateData(this.mer_id, userData).subscribe(data=>{
              alert("Data Updated Successfully");
              close();
            })
    } else {
      alert("All field are Necessary!");
    }
  }
  ngOnInit(): void {
  }

}

 