import { Component } from '@angular/core';
import { ApicallService } from './apicall.service';
declare const hide:any
declare var enrollno:any
declare const hideRegisterForm: any, showRegisterForm: any
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.css']
})
export class AppComponent {
  mer_name:String = "";
  contact_num:Number| undefined  ;
  pincode:Number|undefined;
  location:String = "";
  mer_id:Number|undefined;
  website:String = "";
  phone_num:Number|undefined;
  avg_daily_transaction:Number|undefined;
  shlg = false
  constructor(private apicall: ApicallService){
    
  }
  
  hideRegisterPage(){
    hideRegisterForm();
  }
  showRegisterPage(){
    showRegisterForm();
  }
  
  getRandomInt(max:any) {
    return Math.floor(Math.random() * max);
  }

  register(){
    
      var enrno = this.getRandomInt(200)
      if (this.mer_name != "" && this.phone_num != null && this.contact_num != null 
            && this.pincode != null && this.website != "" &&  this.location != "" && this.avg_daily_transaction != null) {
              
              const userData = {
                mer_id: enrno,
                mer_name: this.mer_name,
                phone_num: this.phone_num,
                contact_num: this.contact_num,
                pincode: this.pincode,
                website: this.website,
                location: this.location,
                avg_daily_transaction: this.avg_daily_transaction
              }
        
              this.apicall.saveData(userData).subscribe(data=>{
                enrollno = enrno;
                alert("Your Enroll no.:-"+enrno);
                this.hideRegisterPage();
                hide();
              })
      } else {
        alert("All field are Necessary!");
      }
    }
  }