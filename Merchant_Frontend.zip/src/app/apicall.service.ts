import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
@Injectable({
  providedIn: 'root'
})
export class ApicallService {

  constructor(private http:HttpClient) { }
  getData(){
    let url = "http://localhost:9000/mydb/";
    return this.http.get(url);
  }
  saveData(user:any){
    let url = "http://localhost:9000/mydb/";
    return this.http.post(url, user);
  }
  deleteData(mer_id: Number){
    let url = "http://localhost:9000/mydb/"+mer_id;
    return this.http.delete(url);
  }
  updateData(mer_id: Number, data: any){
    let url = "http://localhost:9000/mydb/"+mer_id;
    return this.http.put(url, data);
  }
  getByMerchantId(mer_id: Number){
    let url = "http://localhost:9000/mydb/"+mer_id;
    return this.http.get(url);
  }
}
