import { Component, OnInit } from '@angular/core';
declare var logoutValue:any
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.css']
})
export class HomeComponent implements OnInit {

  constructor() { 
    if (logoutValue) {
      window.location.reload();
      logoutValue = false;
    }
  }

  ngOnInit(): void {
  }

}
