var enrollno = ""
var logoutValue = false;
function hide()
{
    document.getElementById("credform").style.visibility = "hidden";
    document.getElementById("rightbar").style.visibility = "visible"; 
}
function showRegisterForm(){
    document.getElementById("registerForm").style.visibility = "visible";
}
function hideRegisterForm() {
    document.getElementById("registerForm").style.visibility = "hidden";    
}