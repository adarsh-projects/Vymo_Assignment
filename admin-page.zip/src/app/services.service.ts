import { Injectable } from '@angular/core';
import {HttpClient } from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class ServicesService {
  constructor(private http:HttpClient) { }
  getData(){
    let url = "http://localhost:9000/mydb/";
    return this.http.get(url);
  }
  deleteData(mer_id:any){
    let url = "http://localhost:9000/mydb/"+mer_id;
    return this.http.delete(url);
  }
  getByMerchnatid(mer_id: Number){
    let url = "http://localhost:9000/mydb/"+mer_id;
    return this.http.get(url);
  }
  updateData(mer_id: Number, user: any){
    let url = "http://localhost:9000/mydb/"+mer_id;
    return this.http.put(url, user);
  }
}
