function show() {
    document.getElementById('m1').style.visibility = 'visible'
}
function close() {
    document.getElementById('m1').style.visibility = 'hidden'
}