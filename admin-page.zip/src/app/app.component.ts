import { Component } from '@angular/core';
import { ServicesService } from './services.service';
import { Router } from '@angular/router';
declare const show:any
declare const close:any
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'example';
  datas:any;
  p: number = 1;
  count: number = 5;
  mer_name:String = "";
  contact_num:Number = 0  ;
  pincode:Number = 0;
  location:String = "";
  mer_id:Number = 0;
  website:String = "";
  phone_num:Number = 0;
  avg_daily_transaction:Number = 0;
  constructor(private service:ServicesService, private router: Router){
    this.service.getData().subscribe(data=>{
      this.datas = data;
    });
  }
  showAll(){
    this.service.getData().subscribe(data=>{
      this.datas = data;
    });
  }
  deletedata(mer_id:Number){
    let res = prompt("Type 'DELETE' To delete.")
    if(res=="DELETE"){
      this.service.deleteData(mer_id).subscribe(data=>{
        alert(this.mer_id +", delete Successfully!")
      })
      window.location.reload();
    }
  }
  updatedata(mer_id: Number){
    show()
    this.service.getByMerchnatid(mer_id).subscribe(data=>{
      let obj = JSON.parse(JSON.stringify(data))[0];
      console.log(obj);
      this.mer_id = obj.mer_id
      this.mer_name = obj.mer_name;
      this.phone_num = obj.phone_num;
      this.contact_num = obj.contact_num;
      this.pincode = obj.pincode;
      this.website = obj.website;
      this.location = obj.location;
      this.avg_daily_transaction = obj.avg_daily_transaction;
    });
  }
  closedata(){
      close();    
  }
  savedata(){
    if (this.mer_id > 0 && this.mer_name != "" && this.phone_num > 0 && this.contact_num > 0 
          && this.pincode > 0 && this.website != "" &&  this.location != "" && this.avg_daily_transaction > 0) {
            const userData = {
              mer_id: this.mer_id,
              mer_name: this.mer_name,
              phone_num: this.phone_num,
              contact_num: this.contact_num,
              pincode: this.pincode,
              website: this.website,
              location: this.location,
              avg_daily_transaction: this.avg_daily_transaction
            }
      
            this.service.updateData(this.mer_id, userData).subscribe(data=>{
              alert("Data Updated Successfully");
              window.location.reload();
              close();
            })
    } else {
      alert("All field are Necessary!");
    }
      
  }
}
