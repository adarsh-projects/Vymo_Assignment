const express = require('express')
const router = express.Router()

const {Merchant} = require('../model/merchant') 

//get All data
router.get('/', async(req, res)=>{
    try{
        const merchant = await Merchant.find()
        res.json(merchant)
    }catch(err){
        res.send(err);
    }
})

router.get('/:mer_id', async(req, res)=>{
    try{
        const merchant = await Merchant.find({mer_id: req.params.mer_id});
        res.json(merchant)
    }catch(err){
        res.send(err);
    }
})
//insert data
router.post('/', async(req, res)=>{
    const merchant = new Merchant({
        mer_name: req.body.mer_name,
        mer_id: req.body.mer_id,
        contact_num: req.body.contact_num,
        pincode: req.body.pincode,
        location: req.body.location,
        website: req.body.website,
        phone_num: req.body.phone_num,
        avg_daily_transaction: req.body.avg_daily_transaction
    })
    try{
        const a1 = await merchant.save()
        res.json(a1);
    }catch(err){
        res.send('Error')
    }
})

router.put('/:mer_id', async(req, res)=>{
    try{        
        const user = await Merchant.find({mer_id: req.params.mer_id});
        const a2 = await Merchant.replaceOne({mer_id: req.params.mer_id}, {
            _id: req.body._id === undefined ? user[0]._id : req.body._id,
            mer_name: req.body.mer_name === undefined ? user[0].mer_name : req.body.mer_name,
            mer_id: req.body.mer_id === undefined ? user[0].mer_id : req.body.mer_id,
            contact_num: req.body.contact_num === undefined ? user[0].contact_num : req.body.contact_num,
            pincode: req.body.pincode === undefined ? user[0].pincode : req.body.pincode,
            location: req.body.location === undefined ? user[0].location : req.body.location,
            website: req.body.website === undefined ? user[0].website : req.body.website,
            phone_num: req.body.phone_num === undefined ? user[0].phone_num : req.body.phone_num,
            avg_daily_transaction: req.body.avg_daily_transaction === undefined ? user[0].avg_daily_transaction : req.body.avg_daily_transaction,
        })
        res.json(a2);
    }catch(err){
        res.send(err)
    }
})

router.delete('/:mer_id', async(req, res)=>{
    try{
        const cq = await Merchant.deleteOne({mer_id: req.params.mer_id})
        res.send(cq);
    }catch(err){
        res.send('Error')
    }
})

module.exports = router