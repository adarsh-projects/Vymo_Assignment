const mongoose = require('mongoose')

const merchantSchema = new mongoose.Schema({
    mer_id:Number,
    mer_name: String,
    contact_num: Number,
    pincode: Number,
    location: String,
    website: String,
    phone_num: Number,
    avg_daily_transaction: Number
})

const Merchant = mongoose.model('merchant', merchantSchema)

module.exports = {
    Merchant
}