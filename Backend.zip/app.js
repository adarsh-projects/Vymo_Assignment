const express = require('express')
const mongoose = require('mongoose')
const url = "mongodb://localhost/mydb"
const app  = express()

mongoose.connect(url, {useNewUrlParser:true})
const con = mongoose.connection

app.use(function(req, res, next){
    res.setHeader('Access-Control-Allow-Origin', '*');//http:localhost:4200/
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
    res.setHeader('Access-Control-Allow-Credentials', true);
    next();
})

con.on('open', function(){
    console.log('connected...')
})

app.use(express.json())


const merchantRouter = require('./routers/merchant')
app.use('/mydb', merchantRouter)

app.listen(9000, function(){
    console.log('Server Started')
})